<?php
//Database credentials
define("DATABASE", "lab_post");
define("SERVER", "localhost");
define("USERNAME", "root");
define("PASSWD", "");

?>
